#!/bin/sh
python CKY.py --grammar grammar.txt --input_sentence "giant cuts in welfare" --print_parsetable

